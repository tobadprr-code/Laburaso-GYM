<?php
// includes/nav.php — barra lateral compartida
// Uso: require_once 'includes/nav.php'; navBar('automatizacion');
// El parámetro es la página activa

function navBar($active = '') {
    $vencidos_badge = '';
    global $conn;
    if ($conn) {
        $r = $conn->query("SELECT COUNT(*) as t FROM clientes WHERE estado IN ('vencido','por_vencer')");
        $n = $r ? $r->fetch_assoc()['t'] : 0;
        if ($n > 0) $vencidos_badge = "<span class='nav-badge'>{$n}</span>";
    }
    $items = [
        ['href'=>'index.php',          'icon'=>'📊', 'label'=>'Dashboard',      'key'=>'dashboard'],
        ['href'=>'clientes.php',        'icon'=>'👥', 'label'=>'Socios',         'key'=>'clientes'],
        ['href'=>'registro.php',        'icon'=>'➕', 'label'=>'Nuevo socio',    'key'=>'registro'],
        ['href'=>'automatizacion.php',  'icon'=>'⚡', 'label'=>'Automatización', 'key'=>'automatizacion'],
        ['href'=>'avisos.php',          'icon'=>'📲', 'label'=>'Avisos',         'key'=>'avisos', 'badge'=>$vencidos_badge],
        ['href'=>'renovar.php',         'icon'=>'🔄', 'label'=>'Renovar',        'key'=>'renovar'],
        ['href'=>'estadisticas.php',    'icon'=>'📈', 'label'=>'Estadísticas',   'key'=>'estadisticas'],
        ['href'=>'resumen_whatsapp.php','icon'=>'💬', 'label'=>'Resumen WA',     'key'=>'resumen'],
        ['href'=>'perfil_socio.php',    'icon'=>'👤', 'label'=>'Perfil socio',   'key'=>'perfil'],
    ];
    $extras = [
        ['href'=>'configuracion.php',   'icon'=>'⚙️',  'label'=>'Configuración', 'key'=>'config'],
        ['href'=>'exportar.php',        'icon'=>'📥', 'label'=>'Exportar CSV',   'key'=>'exportar'],
    ];
    echo '<aside class="sidebar">';
    echo '<div class="sidebar-logo">';
    echo '<div class="logo-text">GYM<span>FLOW</span></div>';
    echo '<div class="logo-sub">AI · Sistema de gestión</div>';
    echo '</div>';
    echo '<nav class="sidebar-nav">';
    echo '<div class="nav-section">Principal</div>';
    foreach ($items as $item) {
        $cls = $active === $item['key'] ? 'nav-item active' : 'nav-item';
        $badge = $item['badge'] ?? '';
        echo "<a href='{$item['href']}' class='{$cls}'>";
        echo "<span class='nav-icon'>{$item['icon']}</span>{$item['label']}{$badge}";
        echo "</a>";
    }
    echo '<div class="nav-section" style="margin-top:.5rem">Configuración</div>';
    foreach ($extras as $item) {
        $cls = $active === $item['key'] ? 'nav-item active' : 'nav-item';
        echo "<a href='{$item['href']}' class='{$cls}'>";
        echo "<span class='nav-icon'>{$item['icon']}</span>{$item['label']}";
        echo "</a>";
    }
    echo '</nav>';
    echo '<div class="sidebar-footer">';
    echo '<a href="logout.php">🚪 Cerrar sesión</a>';
    echo '</div>';
    echo '</aside>';
}
?>
